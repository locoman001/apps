.class public final Landroid/support/compat/R$drawable;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/support/compat/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "drawable"
.end annotation


# static fields
.field public static final notification_action_background:I = 0x7f020085

.field public static final notification_bg:I = 0x7f020086

.field public static final notification_bg_low:I = 0x7f020087

.field public static final notification_bg_low_normal:I = 0x7f020088

.field public static final notification_bg_low_pressed:I = 0x7f020089

.field public static final notification_bg_normal:I = 0x7f02008a

.field public static final notification_bg_normal_pressed:I = 0x7f02008b

.field public static final notification_icon_background:I = 0x7f02008c

.field public static final notification_template_icon_bg:I = 0x7f020091

.field public static final notification_template_icon_low_bg:I = 0x7f020092

.field public static final notification_tile_bg:I = 0x7f02008d

.field public static final notify_panel_notification_icon_bg:I = 0x7f02008e


# direct methods
.method public constructor <init>()V
    .locals 0

    .prologue
    .line 52
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
