.class public final Landroid/support/compat/R$style;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/support/compat/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "style"
.end annotation


# static fields
.field public static final TextAppearance_Compat_Notification:I = 0x7f090084

.field public static final TextAppearance_Compat_Notification_Info:I = 0x7f090085

.field public static final TextAppearance_Compat_Notification_Line2:I = 0x7f090100

.field public static final TextAppearance_Compat_Notification_Time:I = 0x7f090088

.field public static final TextAppearance_Compat_Notification_Title:I = 0x7f09008a

.field public static final Widget_Compat_NotificationActionContainer:I = 0x7f09008c

.field public static final Widget_Compat_NotificationActionText:I = 0x7f09008d


# direct methods
.method public constructor <init>()V
    .locals 0

    .prologue
    .line 108
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
