.class public final Landroid/support/mediacompat/R$layout;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/support/mediacompat/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "layout"
.end annotation


# static fields
.field public static final notification_action:I = 0x7f04001d

.field public static final notification_action_tombstone:I = 0x7f04001e

.field public static final notification_media_action:I = 0x7f04001f

.field public static final notification_media_cancel_action:I = 0x7f040020

.field public static final notification_template_big_media:I = 0x7f040021

.field public static final notification_template_big_media_custom:I = 0x7f040022

.field public static final notification_template_big_media_narrow:I = 0x7f040023

.field public static final notification_template_big_media_narrow_custom:I = 0x7f040024

.field public static final notification_template_custom_big:I = 0x7f040025

.field public static final notification_template_icon_group:I = 0x7f040026

.field public static final notification_template_lines_media:I = 0x7f040027

.field public static final notification_template_media:I = 0x7f040028

.field public static final notification_template_media_custom:I = 0x7f040029

.field public static final notification_template_part_chronometer:I = 0x7f04002a

.field public static final notification_template_part_time:I = 0x7f04002b


# direct methods
.method public constructor <init>()V
    .locals 0

    .prologue
    .line 106
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
