.class public final Landroid/support/mediacompat/R$attr;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/support/mediacompat/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "attr"
.end annotation


# static fields
.field public static final font:I = 0x7f0100bf

.field public static final fontProviderAuthority:I = 0x7f0100b8

.field public static final fontProviderCerts:I = 0x7f0100bb

.field public static final fontProviderFetchStrategy:I = 0x7f0100bc

.field public static final fontProviderFetchTimeout:I = 0x7f0100bd

.field public static final fontProviderPackage:I = 0x7f0100b9

.field public static final fontProviderQuery:I = 0x7f0100ba

.field public static final fontStyle:I = 0x7f0100be

.field public static final fontWeight:I = 0x7f0100c0


# direct methods
.method public constructor <init>()V
    .locals 0

    .prologue
    .line 10
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
